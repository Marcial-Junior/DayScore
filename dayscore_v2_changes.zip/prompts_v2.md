# DayScore – Prompts de Atualização v2

---

## MUDANÇA 1 — Mais emojis no seletor de ícone (Routine)

> "Update the habit icon picker in the Routine tab. Currently it only shows a few emoji options. I want a full emoji picker with: a search input at the top; category filter pills below the search (All, Health, Work, Mind, Home, Fun); a grid of at least 30 emoji options organized by category. The selected emoji should have a purple highlight. Use this emoji list as a starting point organized by category:
> Health: ⏰ 🏃 🧘 💧 🥗 😴 🏋️ 🚴 💊 🫁 🚿 🦷
> Work: 💼 📧 💰 🎯 📊 📝 ✍️ 💻 📞 🗂️
> Mind: 🧠 📚 🙏 🎵 🎨 📖 🌿 🧩 ✨
> Home: 🏠 🧹 🍳 🛒 🐶 🌱 ☕
> Fun: 🎮 🎸 ⚽ 🏊 🎬 🎤
> Keep all existing logic."

---

## MUDANÇA 2 — Remover barra de progresso do card de Routine

> "In the Routine tab, remove the progress bar that fills across the week from each habit card. Keep everything else: the habit icon, name, time, weekday dots (M T W T F), streak tag (🔥 Xd), and the check button. The card should feel cleaner without the bar. See attached mockup for reference."

---

## MUDANÇA 3 — Destacar o horário no card de Routine

> "In the Routine tab, make the time display more prominent in each habit card. Change the time text to font-size 12px, font-weight 700, and color #534AB7 (the app's purple). It should appear below the habit name and above the weekday dots, so the visual order inside the card is: name → time (bold purple) → weekday dots + streak. See attached mockup for reference."

---

## MUDANÇA 4 — Tasks com prazo futuro aparecem no dia correto

> "Fix the task due date behavior. Currently a task with a future due date only shows on today's view. The correct behavior should be:
> 1. When a task has a due date, it should appear in the day view of that specific date — not only today.
> 2. In the week strip, if a day has tasks due, show a small amber dot below that day number (similar to the green dot for completed days).
> 3. When the user taps a day in the week strip, the task list filters to show tasks due on that day.
> 4. Tasks without a due date only show on today's view.
> 5. If a task with a future due date is also visible today (because the user created it today), show a small 'Due tomorrow' or 'Due Apr 1' label below the task name, and a badge on the right showing the date.
> 6. Add an empty state (📭 icon + 'No tasks for this day') when a selected day has no tasks.
> See attached mockup for the visual reference. Keep all localStorage logic."

---

## DICA
Faça uma mudança por vez e teste no celular antes de avançar.
Se algo quebrar: "This broke after the last change. Here is the error: [erro]. Please fix only this without changing anything else."
